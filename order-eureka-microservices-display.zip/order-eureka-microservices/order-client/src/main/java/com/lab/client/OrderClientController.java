package com.lab.client;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/client/orders")
public class OrderClientController {

    private final RestTemplate restTemplate;

    public OrderClientController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @GetMapping("/display")
    public String displayOrderServiceInstance() {
        return restTemplate.getForObject(
            "http://ORDER-SERVICE/display",
            String.class
        );
    }
}
