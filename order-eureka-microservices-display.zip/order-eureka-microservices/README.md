# Order Service + Eureka Discovery Lab

This Maven multi-module project demonstrates a Eureka registry and two running instances of the same Order Service.

## Ports
- Eureka Server dashboard: http://localhost:8076
- Order Service instance 1: http://localhost:8081/display
- Order Service instance 2: http://localhost:8082/display
- Order Client (load-balanced caller): http://localhost:8080/client/orders/display

## Requirements
- JDK 17+
- Maven 3.8+
- Git

## Run in Spring Tool Suite / Eclipse
Import the root folder as **Existing Maven Projects**. Wait for Maven dependencies to finish downloading.

Start in this order:
1. Run `EurekaServerApplication` from the `eureka-server` module.
2. Run `OrderServiceApplication` once with default configuration (or set program arguments `--server.port=8081 --eureka.instance.instance-id=order-service-8081`).
3. Run `OrderServiceApplication` a second time as a separate Java application with program arguments `--server.port=8082 --eureka.instance.instance-id=order-service-8082`.
4. Run `OrderClientApplication` from `order-client`.

In STS, to run the same class twice: **Run > Run Configurations > Spring Boot App > New launch configuration** for the second instance, then enter the program arguments shown above. Ensure the first instance is using port 8081.

## Run using terminal
Open a terminal in the project root:

```bash
mvn clean package
```

Start each component in a separate terminal.

Terminal 1:
```bash
java -jar eureka-server/target/eureka-server-1.0.0.jar
```

Terminal 2:
```bash
java -jar order-service/target/order-service-1.0.0.jar --server.port=8081 --eureka.instance.instance-id=order-service-8081
```

Terminal 3:
```bash
java -jar order-service/target/order-service-1.0.0.jar --server.port=8082 --eureka.instance.instance-id=order-service-8082
```

Terminal 4:
```bash
java -jar order-client/target/order-client-1.0.0.jar
```

## Test
- Open http://localhost:8076 and check that `ORDER-SERVICE` has two instances registered.
- Open `http://localhost:8081/display` and `http://localhost:8082/display`; the responses should identify different ports/instance IDs.
- Refresh `http://localhost:8080/client/orders/display` repeatedly. Spring Cloud LoadBalancer chooses a registered `ORDER-SERVICE` instance; responses should alternate between instance IDs over repeated requests (the sequence is not guaranteed to start with either instance).
- List sample orders: `http://localhost:8081/orders` or `http://localhost:8082/orders`.

## GitHub push
Create an empty repository on GitHub first. Then, in this project root:

```bash
git init
git add .
git commit -m "Add Eureka order service instances and load balancing"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the remote URL with your own repository URL. If `origin` already exists, run `git remote -v`; update it with `git remote set-url origin YOUR-REPOSITORY-URL` rather than adding it again.

## Notes
- The two Order Service instances are the same application running on different ports. The simple display endpoint is GET /display.
- Eureka uses port **8076** as requested.
- This is a lab/demo project; do not treat the default configuration as production security configuration.
